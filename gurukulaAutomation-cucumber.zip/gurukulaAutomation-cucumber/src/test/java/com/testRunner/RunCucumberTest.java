package com.testRunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@SuppressWarnings("deprecation")
@RunWith(Cucumber.class)
@CucumberOptions(plugin = "pretty", features = "./resources/", glue = { "" }, tags = "@EndToEndTest")
public class RunCucumberTest {
}
