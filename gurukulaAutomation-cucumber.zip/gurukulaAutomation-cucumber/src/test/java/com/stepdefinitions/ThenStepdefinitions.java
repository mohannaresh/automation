package com.stepdefinitions;

import com.gurukulaInterface.GurukulaInterface;
import com.utility.DataHelper;

import cucumber.api.java.en.Then;

public class ThenStepdefinitions {

	GurukulaInterface gurukulaInterface;
	DataHelper dataHelper;

	@Then("^they validates that user should be able to login successfully into the application$")
	public void they_validates_that_user_should_be_able_to_login_successfully_into_the_application() throws Throwable {

		gurukulaInterface = new GurukulaInterface();
		gurukulaInterface.verifySuccessfulLoginIntoGurukulaApplication();

	}

	@Then("^they verifies that new branch is created successfully$")
	public void they_verifies_that_new_branch_is_created_successfully() throws Throwable {
		gurukulaInterface = new GurukulaInterface();
		gurukulaInterface.verifyNewBranchIsCreated();
	}

	@Then("^they verifies that updated record information is present on branches page$")
	public void they_verifies_that_updated_record_information_is_present_on_branches_page() throws Throwable {
		gurukulaInterface = new GurukulaInterface();
		gurukulaInterface.verifyRecordIsUpdatedWithNewValues(WhenStepdefinitions.dataHelper);
	}

	@Then("^they verifies that correct branch information is displayed in test results$")
	public void they_verifies_that_correct_branch_information_is_displayed_in_test_results() throws Throwable {
		gurukulaInterface = new GurukulaInterface();
		gurukulaInterface.verifyCorrectRecordDisplayedInSearchResults(WhenStepdefinitions.dataHelper);
	}

	@Then("^they verifies that view information shown is correct$")
	public void they_verifies_that_view_information_shown_is_correct() throws Throwable {
		gurukulaInterface = new GurukulaInterface();
		gurukulaInterface.verifyViewInformationForASpecificBranch(WhenStepdefinitions.dataHelper);
	}

	@Then("^they verifies that removed branch is not present in the branch table$")
	public void they_verifies_that_removed_branch_is_not_present_in_the_branch_table() throws Throwable {
		gurukulaInterface = new GurukulaInterface();
		gurukulaInterface.verifyRecordIsDeletedSuccessfully(WhenStepdefinitions.dataHelper);
	}

	@Then("^they verifies that removed staff information is not present in the staff table$")
	public void they_verifies_that_removed_staff_information_is_not_present_in_the_staff_table() throws Throwable {
		gurukulaInterface = new GurukulaInterface();
		gurukulaInterface.verifyStaffRecordIsDeletedSuccessfully(WhenStepdefinitions.dataHelper);
	}

	@Then("^they verifies that new staff record is created successfully$")
	public void they_verifies_that_new_staff_record_is_created_successfully() throws Throwable {
		gurukulaInterface = new GurukulaInterface();
		gurukulaInterface.verifyNewStaffIsCreated();

	}

	@Then("^they verifies that updated record information is present on staffs page$")
	public void they_verifies_that_updated_record_information_is_present_on_staffs_page() throws Throwable {
		gurukulaInterface = new GurukulaInterface();
		gurukulaInterface.verifyStaffRecordIsUpdatedWithNewValues(WhenStepdefinitions.dataHelper);
	}

	@Then("^they verifies that correct staff information is displayed in test results$")
	public void they_verifies_that_correct_staff_information_is_displayed_in_test_results() throws Throwable {
		gurukulaInterface = new GurukulaInterface();
		gurukulaInterface.verifyCorrectRecordDisplayedInSearchResults(WhenStepdefinitions.dataHelper);
	}
	
	@Then("^they validates that there is hard stop error message displayed as \"([^\"]*)\"$")
	public void they_validates_that_there_is_hard_stop_error_message_displayed_as(String expectedErrorMessage) throws Throwable {
		gurukulaInterface = new GurukulaInterface();
		gurukulaInterface.verifyExpectedErroMessage(expectedErrorMessage);
	}

}
