package com.stepdefinitions;

import com.gurukulaInterface.GurukulaInterface;

import cucumber.api.java.en.Given;

public class GivenStepdefinitions {
	GurukulaInterface gurukulaInterface;

	@Given("^user launches the gurukula application$")
	public void user_launches_the_gurukula_application() throws Throwable {
		gurukulaInterface = new GurukulaInterface();
		gurukulaInterface.launchGurukulaApplication();
		gurukulaInterface.clickLoginLink();
	}

	@Given("^user logs into the application$")
	public void user_logs_into_the_application() throws Throwable {
		gurukulaInterface = new GurukulaInterface();
		gurukulaInterface.launchGurukulaApplication();
		gurukulaInterface.clickLoginLink();
		gurukulaInterface.enterUserCredentailsAndClickAuthenticate();
		gurukulaInterface.verifySuccessfulLoginIntoGurukulaApplication();
	}

}
