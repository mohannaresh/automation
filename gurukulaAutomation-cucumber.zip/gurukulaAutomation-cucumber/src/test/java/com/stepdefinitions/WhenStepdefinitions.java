package com.stepdefinitions;

import com.gurukulaInterface.GurukulaInterface;
import com.utility.DataHelper;

import cucumber.api.java.en.When;

public class WhenStepdefinitions {
	GurukulaInterface gurukulaInterface;
	public static DataHelper dataHelper = new DataHelper();

	@When("^they enters proper credentials$")
	public void they_enters_proper_credentials() throws Throwable {
		gurukulaInterface = new GurukulaInterface();
		gurukulaInterface.enterUserCredentailsAndClickAuthenticate();
	}

	@When("^they enters required \"([^\"]*)\" along with \"([^\"]*)\"$")
	public void they_enters_required_branch_along_with(String branchName, String branchCode) throws Throwable {
		dataHelper.setBranchCode(branchCode);
		dataHelper.setBranchName(branchName);
		gurukulaInterface = new GurukulaInterface();
		gurukulaInterface.selectBranchFromEntitiesMenu();
		gurukulaInterface.createNewBranch(dataHelper.getBranchName(), dataHelper.getBranchCode());

	}

	@When("^they try to edit the branch information with \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void they_try_to_edit_the_branch_information_with(String recordId, String updatedBranchName,
			String updatedBranchCode) throws Throwable {
		dataHelper.setRecordId(recordId);
		dataHelper.setUpdatedBranchCode(updatedBranchCode);
		dataHelper.setUpdatedBranchName(updatedBranchName);
		gurukulaInterface = new GurukulaInterface();
		gurukulaInterface.selectBranchFromEntitiesMenu();
		gurukulaInterface.editBranchInformation(dataHelper);

	}

	@When("^they try to edit the staff information with \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void they_try_to_edit_the_staff_information_with(String recordId, String updatedStaffName,
			String updatedBranchNameOfStaff) throws Throwable {
		dataHelper.setRecordId(recordId);
		dataHelper.setUpdatedStaffName(updatedStaffName);
		dataHelper.setUpdatedBranchNameOfStaff(updatedBranchNameOfStaff);
		gurukulaInterface = new GurukulaInterface();
		gurukulaInterface.selectStaffOptionFromEntitiesMenu();
		gurukulaInterface.editStaffInformation(dataHelper);

	}

	@When("^they try to search for a specific branch with \"([^\"]*)\"$")
	public void they_try_to_search_for_a_specific_branch_with(String recordId) throws Throwable {
		dataHelper.setRecordId(recordId);
		gurukulaInterface = new GurukulaInterface();
		gurukulaInterface.selectBranchFromEntitiesMenu();
		gurukulaInterface.searchForASpecificBranch(dataHelper);

	}

	@When("^they try to search for a specific branch with required information like \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void they_try_to_search_for_a_specific_branch_with_required_information_like(String recordId,
			String branchName, String branchCode) throws Throwable {
		dataHelper.setRecordId(recordId);
		dataHelper.setBranchName(branchName);
		dataHelper.setBranchCode(branchCode);
		gurukulaInterface = new GurukulaInterface();
		gurukulaInterface.selectBranchFromEntitiesMenu();
		gurukulaInterface.searchForASpecificBranch(dataHelper);

	}

	@When("^they click on view button for specific record$")
	public void they_click_on_view_button_for_specific_record() throws Throwable {
		gurukulaInterface = new GurukulaInterface();
		gurukulaInterface.viewASpecificBranch(dataHelper);

	}

	@When("^they try to delete the specific branch$")
	public void they_try_to_delete_the_specific_branch() throws Throwable {
		gurukulaInterface = new GurukulaInterface();
		gurukulaInterface.deleteASpecificBranch(dataHelper);
	}

	@When("^they enters required information of \"([^\"]*)\" along with \"([^\"]*)\"$")
	public void they_enters_required_information_of_along_with(String staffName, String branchNameOfStaff)
			throws Throwable {
		dataHelper.setStaffName(staffName);
		dataHelper.setBranchNameOfStaff(branchNameOfStaff);
		gurukulaInterface = new GurukulaInterface();
		gurukulaInterface.selectStaffOptionFromEntitiesMenu();
		gurukulaInterface.createNewStaff(dataHelper);

	}

	@When("^they try to search for a specific staff member with \"([^\"]*)\"$")
	public void they_try_to_search_for_a_specific_staff_member_with(String recordId) throws Throwable {
		dataHelper.setRecordId(recordId);
		gurukulaInterface = new GurukulaInterface();
		gurukulaInterface.selectStaffOptionFromEntitiesMenu();
		gurukulaInterface.searchForASpecificStaffMember(dataHelper);
	}

	@When("^they try to delete the specific staff member record$")
	public void they_try_to_delete_the_specific_staff_member_record() throws Throwable {
		gurukulaInterface = new GurukulaInterface();
		gurukulaInterface.deleteASpecificStaffRecord(dataHelper);
	}
	
	@When("^they select autheticate option from account dropdown$")
	public void they_select_autheticate_option_from_account_dropdown() throws Throwable {
		gurukulaInterface = new GurukulaInterface();
		gurukulaInterface.selectAnOptionFromAccountDropDown("Authenticate");
	}
	
	@When("^they try to register with new user information after clicking on register new account link$")
	public void they_try_to_register_with_new_user_information_after_clicking_on_register_new_account_link() throws Throwable {
		gurukulaInterface = new GurukulaInterface();
		gurukulaInterface.clickRegisterNewUserLink();
		gurukulaInterface.fillAndSubmitTheNewUserInformation();
	}
	
	@When("^they try to register with new user information after clicking on register new account link under account dropdown$")
	public void they_try_to_register_with_new_user_information_after_clicking_on_register_new_account_link_under_account_dropdown() throws Throwable {
		gurukulaInterface = new GurukulaInterface();
		gurukulaInterface.selectAnOptionFromAccountDropDown("Register");
		gurukulaInterface.fillAndSubmitTheNewUserInformation();	
		
	}

}
