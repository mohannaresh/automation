package com.gurukulaInterface;

import com.pages.BranchesPage;
import com.pages.GurukulaHomePage;
import com.pages.GurukulaLandingPage;
import com.pages.GurukulaLoginPage;
import com.pages.RegistrationPage;
import com.pages.StaffsPage;
import com.pages.ViewBranchPage;
import com.utility.DataHelper;

import junit.framework.Assert;

public class GurukulaInterface {

	GurukulaLandingPage gurukulaLandingPage;
	GurukulaLoginPage gurukulaLoginPage;
	GurukulaHomePage gurukulaHomePage;
	BranchesPage branchesPage;
	ViewBranchPage viewBranchPage;
	StaffsPage staffsPage;
	RegistrationPage registrationPage;
	public static int recordsCountBefore = 0;
	DataHelper dataHelper = new DataHelper();;

	public void launchGurukulaApplication() throws Exception {
		gurukulaLandingPage = new GurukulaLandingPage();
		gurukulaLandingPage.launchGurukulaApplication("chrome", "http://10.0.75.1:8080/#/");

	}

	public void clickLoginLink() throws Exception {
		gurukulaLandingPage = new GurukulaLandingPage();
		gurukulaLandingPage.clickLoginLink();
	}

	public void enterUserCredentailsAndClickAuthenticate() throws Exception {
		gurukulaLoginPage = new GurukulaLoginPage();
		gurukulaLoginPage.enterUserCredentailsAndClickAuthenticate("admin", "admin");

	}

	@SuppressWarnings("deprecation")
	public void verifySuccessfulLoginIntoGurukulaApplication() {
		gurukulaHomePage = new GurukulaHomePage();
		Assert.assertTrue("Failed to verify successfull login message on homepage",
				gurukulaHomePage.verifySuccessfulLogin());
	}

	public void selectBranchFromEntitiesMenu() throws Exception {
		gurukulaHomePage = new GurukulaHomePage();
		gurukulaHomePage.clickOnDropDownBasedOnDisplayText("Entities");
		gurukulaHomePage.selectByVisibleTextFromEntitiesMenu("Branch");
	}

	public void selectStaffOptionFromEntitiesMenu() throws Exception {
		gurukulaHomePage = new GurukulaHomePage();
		gurukulaHomePage.clickOnDropDownBasedOnDisplayText("Entities");
		gurukulaHomePage.selectByVisibleTextFromEntitiesMenu("Staff");
	}

	public void createNewBranch(String branchName, String branchCode) throws Exception {
		dataHelper.setBranchName(branchName);
		dataHelper.setBranchCode(branchCode);
		branchesPage = new BranchesPage();
		recordsCountBefore = branchesPage.getNumberOfRecordsPresent();
		branchesPage.add(branchName, branchCode);

	}

	@SuppressWarnings("deprecation")
	public void verifyNewBranchIsCreated() throws Exception {
		branchesPage = new BranchesPage();
		int recordsCountAfterAdd = branchesPage.getNumberOfRecordsPresent();
		Assert.assertTrue("Failed to add new record",
				branchesPage.verifyNewRecordAdded(recordsCountBefore, recordsCountAfterAdd));

	}

	@SuppressWarnings("deprecation")
	public void verifyNewStaffIsCreated() throws Exception {
		staffsPage = new StaffsPage();
		int recordsCountAfterAdd = staffsPage.getNumberOfRecordsPresent();
		Assert.assertTrue("Failed to add new record",
				staffsPage.verifyNewRecordAdded(recordsCountBefore, recordsCountAfterAdd));

	}

	public void editBranchInformation(DataHelper dataHelper) throws Exception {
		// dataHelper = new DataHelper();
		branchesPage = new BranchesPage();

		branchesPage.edit(Integer.parseInt(dataHelper.getRecordId()), dataHelper.getUpdatedBranchName(),
				dataHelper.getUpdatedBranchCode());
	}

	public void editStaffInformation(DataHelper dataHelper) throws Exception {
		staffsPage = new StaffsPage();
		staffsPage.edit(Integer.parseInt(dataHelper.getRecordId()), dataHelper.getUpdatedStaffName(),
				dataHelper.getUpdatedBranchNameOfStaff());
	}

	@SuppressWarnings("deprecation")
	public void verifyRecordIsUpdatedWithNewValues(DataHelper dataHelper) throws Exception {
		branchesPage = new BranchesPage();
		Assert.assertTrue("Failed to validate the updated branch information",
				branchesPage.verifyRecordIsUpdatedWithNewValues(Integer.parseInt(dataHelper.getRecordId()),
						dataHelper.getUpdatedBranchName(), dataHelper.getUpdatedBranchCode()));

	}

	@SuppressWarnings("deprecation")
	public void verifyStaffRecordIsUpdatedWithNewValues(DataHelper dataHelper) throws Exception {
		staffsPage = new StaffsPage();
		//Thread.sleep(4000);
		Assert.assertTrue("Failed to validate the updated branch or staff information",
				staffsPage.verifyRecordIsUpdatedWithNewValues(Integer.parseInt(dataHelper.getRecordId()),
						dataHelper.getUpdatedStaffName(), dataHelper.getUpdatedBranchNameOfStaff()));
	}

	public void searchForASpecificBranch(DataHelper dataHelper) throws Exception {
		branchesPage = new BranchesPage();
		branchesPage.search(Integer.parseInt(dataHelper.getRecordId()));
	}

	public void searchForASpecificStaffMember(DataHelper dataHelper) throws Exception {
		staffsPage = new StaffsPage();
		staffsPage.search(Integer.parseInt(dataHelper.getRecordId()));
	}

	@SuppressWarnings("deprecation")
	public void verifyCorrectRecordDisplayedInSearchResults(DataHelper dataHelper) throws Exception {
		branchesPage = new BranchesPage();
		Assert.assertTrue("Failed to verify the search record",
				branchesPage.verifySearchRecordIsSuccessfullyDisplayed(Integer.parseInt(dataHelper.getRecordId())));

	}

	@SuppressWarnings("deprecation")
	public void verifyCorrectStaffRecordDisplayedInSearchResults(DataHelper dataHelper) throws Exception {
		staffsPage = new StaffsPage();
		Assert.assertTrue("Failed to verify the search record",
				staffsPage.verifySearchRecordIsSuccessfullyDisplayed(Integer.parseInt(dataHelper.getRecordId())));
	}

	public void viewASpecificBranch(DataHelper dataHelper) throws Exception {
		branchesPage = new BranchesPage();
		branchesPage.view(Integer.parseInt(dataHelper.getRecordId()));

	}

	@SuppressWarnings("deprecation")
	public void verifyViewInformationForASpecificBranch(DataHelper dataHelper) throws Exception {
		viewBranchPage = new ViewBranchPage();
		Assert.assertTrue("Failed to verify the view table for the given input values",
				viewBranchPage.verifyViewInformationForASpecificBranch(Integer.parseInt(dataHelper.getRecordId()),
						dataHelper.getBranchName(), dataHelper.getBranchCode()));

	}

	public void deleteASpecificBranch(DataHelper dataHelper) throws Exception {
		branchesPage = new BranchesPage();
		branchesPage.delete(Integer.parseInt(dataHelper.getRecordId()));
	}

	public void deleteASpecificStaffRecord(DataHelper dataHelper) throws Exception {
		staffsPage = new StaffsPage();
		staffsPage.delete(Integer.parseInt(dataHelper.getRecordId()));
	}

	@SuppressWarnings("deprecation")
	public void verifyRecordIsDeletedSuccessfully(DataHelper dataHelper) throws Exception {
		branchesPage = new BranchesPage();
		Assert.assertFalse("Failed to verify the search record",
				branchesPage.verifySearchRecordIsSuccessfullyDisplayed(Integer.parseInt(dataHelper.getRecordId())));
	}

	@SuppressWarnings("deprecation")
	public void verifyStaffRecordIsDeletedSuccessfully(DataHelper dataHelper) throws Exception {
		staffsPage = new StaffsPage();
		Assert.assertFalse("Failed to verify the search record",
				staffsPage.verifySearchRecordIsSuccessfullyDisplayed(Integer.parseInt(dataHelper.getRecordId())));
	}

	public void createNewStaff(DataHelper dataHelper) throws Exception {
		staffsPage = new StaffsPage();
		// branchesPage = new BranchesPage();
		recordsCountBefore = staffsPage.getNumberOfRecordsPresent();
		staffsPage.add(dataHelper.getStaffName(), dataHelper.getBranchNameOfStaff());

	}
	
	public void selectAnOptionFromAccountDropDown(String optionToSelect) throws Exception {
		gurukulaLandingPage = new GurukulaLandingPage();
		gurukulaLandingPage.selectAnOptionFromAccountDropDown(optionToSelect);
		
	}
	
	public void clickRegisterNewUserLink() throws Exception {
		gurukulaLandingPage = new GurukulaLandingPage();
		gurukulaLandingPage.clickRegisterNewUserLink();
	}
	
	public void fillAndSubmitTheNewUserInformation() throws Exception {
		registrationPage = new RegistrationPage();
		registrationPage.enterLoginText("mohan");
		registrationPage.enterEmail("test@gmail.com");
		registrationPage.enterPassword("password");
		registrationPage.clickRegisterButton();
		
	}
	
	@SuppressWarnings("deprecation")
	public void verifyExpectedErroMessage(String expectedErrorMessage) throws Exception {
		registrationPage = new RegistrationPage();
		Assert.assertTrue("Failed to verify error message", registrationPage.verifyExpectedErroMessage(expectedErrorMessage));
		
	}
}
