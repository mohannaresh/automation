package com.pages;

import org.openqa.selenium.By;

import com.utility.BaseClass;

public class GurukulaLoginPage extends BaseClass {

	private By userName = By.id("username");
	private By password = By.id("password");
	private By authenticateButton = By.xpath("//*[@class='btn btn-primary ng-scope']");

	public void enterUserCredentailsAndClickAuthenticate(String userName, String password) throws Exception {
		type(this.userName, userName);
		type(this.password, password);
		waitForElement(authenticateButton, 3000);
		click(authenticateButton);

	}
}
