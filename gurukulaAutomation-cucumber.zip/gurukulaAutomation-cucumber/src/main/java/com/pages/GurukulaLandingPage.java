package com.pages;

import org.openqa.selenium.By;

import com.utility.BaseClass;

public class GurukulaLandingPage extends BaseClass {
	private By loginLink = By.linkText("login");
	private By accountDropdown = By.xpath("//*[@translate='global.menu.account.main']//ancestor::a");
	private By registerNewUserLink = By.linkText("Register a new account");

	public void launchGurukulaApplication(String browserName, String url) {
		openBrowser(browserName);
		openURL(url);
	}

	public void clickLoginLink() throws Exception {
		click(loginLink);
	}
	
	public void selectAnOptionFromAccountDropDown(String textToSelect) throws Exception {
		click(accountDropdown);
		By option = By.xpath("//span[contains(text(),'"+textToSelect+"')]");
		click(option);
		
	}
	
	public void clickRegisterNewUserLink() throws Exception {
		click(registerNewUserLink);
	}

}
