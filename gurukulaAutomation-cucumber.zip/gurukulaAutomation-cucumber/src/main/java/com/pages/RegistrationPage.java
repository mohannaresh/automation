package com.pages;

import org.openqa.selenium.By;

import com.utility.BaseClass;

public class RegistrationPage extends BaseClass {
	By loginTextBox = By.name("login");
	By emailTextBox = By.name("email");
	By newPasswordTextBox = By.name("password");
	By newPasswordConfirmationTextBox = By.name("confirmPassword");
	By registerButton = By.xpath("//*[@class='btn btn-primary ng-scope']");
	By errorMessage = By.xpath("//*[@translate='register.messages.error.fail']");

	public void enterLoginText(String textToEnter) throws Exception {
		type(loginTextBox, textToEnter);
	}

	public void enterEmail(String email) throws Exception {
		type(emailTextBox, email);
	}

	public void enterPassword(String password) throws Exception {
		type(newPasswordTextBox, password);
		type(newPasswordConfirmationTextBox, password);
	}

	public void clickRegisterButton() throws Exception {
		click(registerButton);
	}

	public boolean verifyExpectedErroMessage(String expectedErrorMessage) throws Exception {
		boolean isExpectedMessagePresent = false;
		waitForElement(errorMessage,7000);
		wait(3000);
		String errorMessageFromWeb = printText(errorMessage);
		if (errorMessageFromWeb.contains(expectedErrorMessage)) {
			isExpectedMessagePresent = true;
		}
		return isExpectedMessagePresent;
	}

}
