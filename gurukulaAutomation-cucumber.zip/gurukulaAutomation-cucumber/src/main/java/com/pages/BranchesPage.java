package com.pages;

import org.openqa.selenium.By;

import com.utility.BaseClass;
import com.utility.GurukulaUserInterface;

public class BranchesPage extends BaseClass implements GurukulaUserInterface {

	By branchesTitle = By.xpath("//*[@translate='gurukulaApp.branch.home.title'and contains(text(),'Branches')]");
	By createNewBranchButton = By.xpath("//*[@class='btn btn-primary']//*[contains(text(),'Create a new Branch')]");
	By nameTextBox = By
			.xpath("//div[@class='form-group' or @class='form-group has-error']//input[@ng-model='branch.name']");
	By codeTextBox = By
			.xpath("//div[@class='form-group' or @class='form-group has-error']//input[@ng-model='branch.code']");
	By saveButton = By.xpath("//*[contains(text(),'Save')]/ancestor::button");
	By numberOfRecordsInBranchTable = By.xpath("//*[@class='table table-striped']//tr");
	By table = By.xpath("//*[@class='table table-striped']");
	By deleteButtonOnAlert = By
			.xpath("//form[@name='deleteForm']//span[@translate='entity.action.delete']//ancestor::button");
	By searchQueryTextBox = By.id("searchQuery");
	By seachQueryButton = By.xpath("//*[@class='btn btn-info']");
	By editFormPopup = By.xpath("//*[@name='editForm']");

	
	  /*public BranchesPage() throws Exception { waitForElement(branchesTitle,
	  10000); }*/
	 

	public void add(String name, String code) {
		try {
			click(createNewBranchButton);
			enterBranchName(name);
			enterBranchCode(code);
			clickSaveButton();
			Thread.sleep(8000);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void edit(int id, String name, String code) {

		By editButton = By.xpath(
				"//a[contains(text(),'" + id + "')]//ancestor::tr//span[contains(text(),'Edit')]/ancestor::button");

		try {
			waitForElement(editButton, 5000);
			click(editButton);
			waitForElement(editFormPopup, 8000);
			enterBranchName(name);
			enterBranchCode(code);
			clickSaveButton();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void view(int id) {
		By viewButton = By.xpath(
				"//a[contains(text(),'" + id + "')]//ancestor::tr//span[contains(text(),'View')]/ancestor::button");

		try {
			waitForElement(viewButton, 5000);
			click(viewButton);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean verifyRecordIsUpdatedWithNewValues(int id, String name, String code) {
		boolean isRecordUpdated = false;
		By nameFieldValue = By
				.xpath("//a[contains(text(),'" + id + "')]//ancestor::tr//td[contains(text(),'" + name + "')]");
		By codeFieldValue = By
				.xpath("//a[contains(text(),'" + id + "')]//ancestor::tr//td[contains(text(),'" + code + "')]");
		if (IsElementPresent(nameFieldValue) && IsElementPresent(codeFieldValue)) {
			isRecordUpdated = true;
		}

		return isRecordUpdated;

	}

	public void delete(int id) {
		By deleteButton = By.xpath(
				"//a[contains(text(),'" + id + "')]//ancestor::tr//span[contains(text(),'Delete')]/ancestor::button");
		try {
			waitForElement(deleteButton, 5000);
			click(deleteButton);
			waitForElement(deleteButtonOnAlert, 5000);
			click(deleteButtonOnAlert);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public boolean verifyIsRecordSuccessfullyDeleted(int id) {
		boolean isRecordDeleted = false;
		By deletedRecordId = By.xpath("//a[contains(text(),'" + id + "')]");
		if (!IsElementPresent(deletedRecordId)) {
			isRecordDeleted = true;
		}

		return isRecordDeleted;
	}

	public void search(int id) {
		try {
			String idValue = Integer.toString(id);
			type(searchQueryTextBox, idValue);
			click(seachQueryButton);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public boolean verifySearchRecordIsSuccessfullyDisplayed(int id) {
		boolean isRecordDisplayed = false;
		By searchedRecordId = By.xpath("//a[contains(text(),'" + id + "')]");
		if (IsElementPresent(searchedRecordId)) {
			isRecordDisplayed = true;
		}

		return isRecordDisplayed;
	}

	public void enterBranchName(String branchName) throws Exception {
		waitForElement(nameTextBox, 5000);
		type(nameTextBox, branchName);

	}

	public void enterBranchCode(String branchCode) throws Exception {
		waitForElement(codeTextBox, 5000);
		type(codeTextBox, branchCode);
	}

	public void clickSaveButton() throws Exception {
		waitForElement(saveButton, 5000);
		click(saveButton);
	}

	public int getNumberOfRecordsPresent() throws Exception {

		waitForElement(table, 5000);
		return totalNumberOfRecords(numberOfRecordsInBranchTable);
	}

	public boolean verifyNewRecordAdded(int recordsCountBefore, int recordsCountAfterAdd) {
		boolean isNewRecordAdded = false;
		if ((recordsCountAfterAdd - recordsCountBefore) == 1) {
			isNewRecordAdded = true;
		}
		return isNewRecordAdded;
	}

}
