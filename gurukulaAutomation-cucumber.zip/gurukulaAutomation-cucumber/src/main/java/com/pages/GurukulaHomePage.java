package com.pages;

import org.openqa.selenium.By;

import com.utility.BaseClass;

public class GurukulaHomePage extends BaseClass {
	private By successfullLoginMessage = By.xpath("//*[@class='alert alert-success ng-scope ng-binding']");

	public boolean verifySuccessfulLogin() {
		return IsElementPresent(successfullLoginMessage);
	}

	public void clickOnDropDownBasedOnDisplayText(String menuName) throws Exception {
		By dropDownLabel = By.xpath("//*[@class='dropdown-toggle']//span[contains(text(),'" + menuName + "')]");
		click(dropDownLabel);

	}

	public void selectByVisibleTextFromEntitiesMenu(String selectText) throws Exception {
		By branchLabel = By.xpath("//*[@class='dropdown-menu']//span[contains(text(),'" + selectText + "')]");
		waitForElement(branchLabel, 5000);
		click(branchLabel);

	}
}
