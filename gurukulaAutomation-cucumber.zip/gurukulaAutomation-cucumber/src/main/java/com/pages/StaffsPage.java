package com.pages;

import org.openqa.selenium.By;

public class StaffsPage extends BranchesPage {

	By staffsPageTitle = By.xpath("//*[@translate='gurukulaApp.staff.home.title']");
	By staffNameField = By.name("name");
	By selectBranchDropdown = By.xpath("//*[@name='related_branch']");
	By createNewStaffButton = By.xpath("//*[@class='btn btn-primary']//*[contains(text(),'Create a new Staff')]");

	public StaffsPage() throws Exception {
		waitForElement(staffsPageTitle, 10000);
	}

	@Override
	public void add(String staffName, String branchNameOfStaff) {
		try {
			click(createNewStaffButton);
			type(staffNameField, staffName);
			select(selectBranchDropdown, branchNameOfStaff);
			clickSaveButton();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public void edit(int recordId, String updatedStaffName, String branchNameOfStaff) {

		By editButton = By.xpath("//a[contains(text(),'" + recordId
				+ "')]//ancestor::tr//span[contains(text(),'Edit')]/ancestor::button");

		try {
			waitForElement(editButton, 5000);
			click(editButton);
			waitForElement(editFormPopup, 8000);
			type(staffNameField, updatedStaffName);
			select(selectBranchDropdown, branchNameOfStaff);
			clickSaveButton();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
