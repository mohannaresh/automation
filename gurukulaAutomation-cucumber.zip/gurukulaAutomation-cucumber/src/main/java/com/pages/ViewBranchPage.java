package com.pages;

import org.openqa.selenium.By;

import com.utility.BaseClass;

public class ViewBranchPage extends BaseClass {
	By viewBranchPageHeader = By.xpath("//*[@translate='gurukulaApp.branch.detail.title']");
	By viewPageHeader = By.xpath("//*[@class='ng-binding']");
	By nameFieldInView = By.xpath("//*[contains(text(),'Name')]//ancestor::tr//*[@class='input-sm form-control']");
	By codeFieldInView = By.xpath("//*[contains(text(),'Code')]//ancestor::tr//*[@class='input-sm form-control']");

	public ViewBranchPage() throws Exception {
		waitForElement(viewBranchPageHeader, 5000);
	}

	public boolean verifyViewInformationForASpecificBranch(int id, String name, String code) throws Exception {
		boolean isViewInformationIsCorrect = false;
		String displayedHeader = printText(viewPageHeader);
		String nameFieldValue = getattributevalue(driver.findElement(nameFieldInView), "value");
		String codeFieldValue = getattributevalue(driver.findElement(codeFieldInView), "value");

		if (displayedHeader.contains(Integer.toString(id)) && nameFieldValue.equalsIgnoreCase(name)
				&& codeFieldValue.equalsIgnoreCase(code)) {
			isViewInformationIsCorrect = true;
		}
		return isViewInformationIsCorrect;

	}
}
