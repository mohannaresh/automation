package com.utility;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class BaseClass {

	public Logger log = Logger.getLogger(BaseClass.class);
	public static WebDriver driver = null;

	public void openBrowser(String browserName) {
		/*
		 * if (browserName.equalsIgnoreCase("firefox")) {
		 * System.setProperty("webdriver.gecko.driver", ".\\drivers\\chromedriver.exe");
		 * driver=new FirefoxDriver(); } else if (browserName.equalsIgnoreCase("ie")) {
		 * System.setProperty("webdriver.ie.driver",
		 * System.getProperty("user.dir")+".\\drivers\\chromedriver.exe"); driver = new
		 * InternetExplorerDriver();
		 * 
		 * } else
		 */ if (browserName.toLowerCase().contains("chrome")) {
			System.setProperty("webdriver.chrome.driver", ".\\drivers\\chromedriver.exe");
			driver = new ChromeDriver();
		}
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}

	public void openURL(String url) throws RuntimeException {
		try {
			driver.get(url);
			log.info("Opened the URL " + url);
		} catch (RuntimeException e) {
			log.fatal("Unable to Open the URL " + e.getMessage());
		}

	}

	public void click(By locator) throws Exception {
		try {
			driver.findElement(locator).click();
			log.info("Clicked on " + locator);
		} catch (Exception e) {
			log.error("Unable to click on " + locator);
		}
	}

	public void type(By locator, String data) throws Exception {
		try {
			driver.findElement(locator).clear();
			driver.findElement(locator).sendKeys(data);
			log.info("Entered the value in the Textbox :" + locator);
		} catch (RuntimeException localRuntimeException) {
			log.fatal("Unable to Enter the value in the Textbox :" + locator);
		}
	}

	public void select(By locator, String data) throws Exception {
		try {
			new Select(driver.findElement(locator)).selectByVisibleText(data);
		} catch (RuntimeException localRuntimeException) {
			log.fatal("Failed to select locator:" + locator);
		}
	}

	public void waitForElement(By locator, int timer) throws Exception {
		try {
			for (int i = 0; i < timer; i++) {
				try {
					driver.findElement(locator).isDisplayed();
					break;
				} catch (RuntimeException localRuntimeException) {
					localRuntimeException.getMessage();
				}
			}
		} catch (RuntimeException localRuntimeException) {
			localRuntimeException.getMessage();
		}
	}

	public boolean IsElementPresent(By locator) {
		boolean expectedElementPresent = false;
		try {
			if (driver.findElement(locator).isDisplayed())
				expectedElementPresent = true;
			log.info("Element is available :" + locator);
		} catch (Exception e) {
			log.error("Element is not available :" + locator);
		}
		return expectedElementPresent;
	}

	public static String getattributevalue(WebElement elem, String requiredattribute) throws Exception {
		String attribute = null;
		try {
			attribute = elem.getAttribute(requiredattribute);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return attribute;
	}

	public String printText(By locator) {
		String text = driver.findElement(locator).getText();
		return text;
	}

	public int totallinnks(WebElement elem) {
		return elem.findElements(By.tagName("a")).size();
	}

	public int totalNumberOfRecords(By locator) {
		return driver.findElements(locator).size();
	}

	public void wait(int ms) {
		try {
			Thread.sleep(ms);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			
		}
	}

}
