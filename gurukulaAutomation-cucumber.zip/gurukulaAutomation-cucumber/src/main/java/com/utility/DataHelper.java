package com.utility;

public class DataHelper {
	private String branchName;
	private String branchCode;
	private String recordId;
	private String updatedBranchName;
	private String updatedBranchCode;
	private String staffName;
	private String branchNameOfStaff;
	private String updatedStaffName;
	private String updatedBranchNameOfStaff;

	public String getUpdatedStaffName() {
		return updatedStaffName == null ? "" : this.updatedStaffName;
	}

	public void setUpdatedStaffName(String updatedStaffName) {
		this.updatedStaffName = updatedStaffName;
	}

	public String getUpdatedBranchNameOfStaff() {
		return updatedBranchNameOfStaff == null ? "" : this.updatedBranchNameOfStaff;
	}

	public void setUpdatedBranchNameOfStaff(String updatedBranchNameOfStaff) {
		this.updatedBranchNameOfStaff = updatedBranchNameOfStaff;
	}

	public String getStaffName() {
		return staffName == null ? "" : this.staffName;
	}

	public void setStaffName(String staffName) {
		this.staffName = staffName;
	}

	public String getBranchNameOfStaff() {
		return branchNameOfStaff == null ? "" : this.branchNameOfStaff;
	}

	public void setBranchNameOfStaff(String branchNameOfStaff) {
		this.branchNameOfStaff = branchNameOfStaff;
	}

	public String getRecordId() {
		return recordId == null ? "1" : this.recordId;
	}

	public void setRecordId(String recordId) {
		this.recordId = recordId;
	}

	public String getUpdatedBranchName() {
		return updatedBranchName == null ? "Default" : this.updatedBranchName;
	}

	public void setUpdatedBranchName(String updatedBrnachName) {
		this.updatedBranchName = updatedBrnachName;
	}

	public String getUpdatedBranchCode() {
		return updatedBranchCode == null ? "Default" : this.updatedBranchCode;
	}

	public void setUpdatedBranchCode(String updatedBranchCode) {
		this.updatedBranchCode = updatedBranchCode;
	}

	public String getBranchName() {
		return branchName == null ? "Chennai" : this.branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getBranchCode() {
		return branchCode == null ? "MAS" : this.branchCode;
	}

	public void setBranchCode(String brnachCode) {
		this.branchCode = brnachCode;
	}

}
