package com.utility;

public interface GurukulaUserInterface {
	public void add(String name, String code);

	public void edit(int id, String name, String code);

	public void delete(int id);

	public void search(int id);

}
